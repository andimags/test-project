/** @type {import('tailwindcss').Config} */
module.exports = {
    content: ["./src/**/*.{html,js}", "./index.html"],
    theme: {
        extend: {},
        // colors: {
        //     primary: "rgb(37 99 235)",
        // },
    },
    plugins: [],
};
